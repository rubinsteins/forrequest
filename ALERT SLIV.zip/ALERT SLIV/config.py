bot_token = '7728340022:AAHI_jXheNvdwAvmpJriWt8-wc1FGU85_5c' #токен бота
admin = [484312705] #айди админов
APIKEY = '' #сюда ничего не вставляй
cryptotoken = '365394:AAwBxKxNzK54Sk2eV30cbPFKixrkqfBff3A' #токен @send
login = 'alertt' #тут меняшеь на имя своего бота
secret = 'c31bfa3ce20ac99728b4efb55cf4ffbeea737f6e' # это не трогаешь 
photo = 'https://i.ibb.co/qY5RcPYg/photo-2025-02-28-09-04-00.jpg' #банер
API = [
    "24565698:5a084b434f8505ace703485b9da85040", # не трогаешь
    "27904162:e7cba879b1c643ba77490bf328df5eab", # не трогаешь
    "23037915:50f06f5b2223586fde0d1379ea91ebc7", # не трогаешь
]
logs_id = -1002277003952# логи айди
channel1_id = -1002618229722 # обязятельная подписка на канал #1
channel2_id = -1002618229722# обязятельная подписка на канал #2