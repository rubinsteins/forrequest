from aiogram.dispatcher.filters.state import StatesGroup, State


class CryptoBot(StatesGroup):
	money = State()

class UserPay(StatesGroup):
	count = State()

class repomessage(StatesGroup):
	link = State()

class repomessagepyrogram(StatesGroup):
	link = State()

class Usersub(StatesGroup):
	transfer_to = State()