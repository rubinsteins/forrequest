from aiogram.dispatcher.filters.state import StatesGroup, State


class givebalance(StatesGroup):
    user = State()
    suma = State()

class getbalance(StatesGroup):
    user = State()
    suma = State()

class getsabaka(StatesGroup):
    user = State()

class GiveSubState(StatesGroup):
    user_id = State()
    days = State()


class BroadcastState(StatesGroup):
    message_text = State()
    button_text = State()
    button_url = State()

class BroadcastStatePhoto(StatesGroup):
    waiting_for_text = State()
    waiting_for_photo_url = State()

class BroadcastStateText(StatesGroup):
    message_text = State()

class foktpaljd(StatesGroup):
    message_text = State()
    button_text = State()
    button_url = State()
    waiting_for_photo_url = State()

class setprice(StatesGroup):
    price = State()